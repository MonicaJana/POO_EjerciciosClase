import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class versaldo extends JFrame {
    private JButton menu;
    private JPanel panel3;

    public versaldo(){
        super("Saldo");
        setContentPane(panel3);


        menu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                transaccion tran=new transaccion();
                tran.iniciar();
                dispose();
            }
        });
    }
    public void iniciar(){

        setVisible(true);
        setLocationRelativeTo(null);
        setSize(400,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
