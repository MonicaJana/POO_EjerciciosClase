import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ingreso extends JFrame{
    private JPasswordField password;
    private JLabel user;
    private JButton ENTERButton;
    private JPanel panel1;

    public ingreso(){
        super("Bienvenido al Banco del Búho");
        setContentPane(panel1);
        ENTERButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String contra="123456";
                String contraIngresada=password.getText();

                if (contra.equals(contraIngresada)){
                    transaccion tran=new transaccion();
                    tran.iniciar();
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null,"Intentar otra vez");
                }

            }
        });
    }
    public void iniciar(){

        setVisible(true);
        setLocationRelativeTo(null);
        setSize(400,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
