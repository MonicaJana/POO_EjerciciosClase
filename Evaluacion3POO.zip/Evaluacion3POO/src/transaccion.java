import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class transaccion extends JFrame{
    private JPanel panel2;
    private JRadioButton depositoRadioButton;
    private JRadioButton retiroRadioButton;
    private JRadioButton verSaldoRadioButton;
    private JButton salir;


    public transaccion (){
        super("Transaccion a realizar");
        setContentPane(panel2);
        verSaldoRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Muchas gracias");
                versaldo saldo=new versaldo();
                saldo.iniciar();
                dispose();
            }
        });
        salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Muchas gracias");
                dispose();
                System.exit(0);
            }
        });
        retiroRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JOptionPane.showMessageDialog(null,"Muchas gracias");
                retiro ret=new retiro();
                ret.iniciar();
                dispose();

            }
        });
        depositoRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"Muchas gracias");
                deposito dep=new deposito();
                dep.iniciar();
                dispose();
            }
        });
    }
    public void iniciar(){

        setVisible(true);
        setLocationRelativeTo(null);
        setSize(400,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
